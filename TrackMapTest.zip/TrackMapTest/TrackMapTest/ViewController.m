//
//  ViewController.m
//  TrackMapTest
//
//  Created by 通拓科技 on 16/4/26.
//  Copyright © 2016年 tomtop. All rights reserved.
//

#import "ViewController.h"
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController ()<MKMapViewDelegate,CLLocationManagerDelegate>

/** 位置管理者 */
@property (nonatomic, strong) CLLocationManager *locationM;
@property (nonatomic, strong) NSMutableArray *rePlayArray;
@property(strong,nonatomic)CLGeocoder *geocoder;
@property (nonatomic, weak) IBOutlet MKMapView *map;

@end

@implementation ViewController


-(CLLocationManager *)locationM
{
    if (!_locationM) {
        
        _locationM = [[CLLocationManager alloc] init];
        
        // 版本适配
        if ([[UIDevice currentDevice].systemVersion floatValue] >= 8.0) {
            [_locationM requestAlwaysAuthorization];
        }
    }
    return _locationM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.detailView setFrame:self.view.bounds];
    [self.detailView setBackgroundColor:[UIColor blackColor]];
    [self.detailView setAlpha:0.5];
    
    [self initLocationManager];
    [self initMapView];
    
    self.rePlayArray = [[NSMutableArray alloc] init];
    [_locationM requestAlwaysAuthorization];
    [self.locationM startUpdatingLocation];
}

// 创建MapView
-(void)initMapView{

    //    MKMapTypeStandard = 0, // 标准地图
    //    MKMapTypeSatellite, // 卫星云图
    //    MKMapTypeHybrid, // 混合(在卫星云图上加了标准地图的覆盖层)
    //    MKMapTypeSatelliteFlyover NS_ENUM_AVAILABLE(10_11, 9_0), // 3D立体
    //    MKMapTypeHybridFlyover NS_ENUM_AVAILABLE(10_11, 9_0), // 3D混合
    // 设置地图显示样式(必须注意,设置时 注意对应的版本)
    self.map.mapType = MKMapTypeStandard;
    self.map.delegate = self;
    // 设置地图的控制项
    // 是否可以滚动
    self.map.scrollEnabled = YES;
    // 缩放
    self.map.zoomEnabled = YES;
    // 旋转
    self.map.rotateEnabled = YES;
    
    // 设置地图的显示项(注意::版本适配)
    // 显示建筑物
    self.map.showsBuildings = YES;
    // 指南针
    self.map.showsCompass = YES;
    // 兴趣点
    self.map.showsPointsOfInterest = YES;
    // 比例尺
    self.map.showsScale = YES;
    // 交通
    self.map.showsTraffic = NO;
    
    // 显示用户位置
    [self locationM];
    
    /**
     *  MKUserTrackingModeNone = 0, 不追踪
     MKUserTrackingModeFollow,  追踪
     MKUserTrackingModeFollowWithHeading, 带方向的追踪
     */
    // 显示用户位置, 自动放大地图到合适的比例(也要进行定位授权)
    self.map.userTrackingMode = MKUserTrackingModeFollowWithHeading;
}

//创建CLLocationManager并启动定位
- (void)initLocationManager{
    //创建CLLocationManager对象并设置代理
    self.locationM = [[CLLocationManager alloc] init];
    self.locationM.delegate = self;
    //设置定位精度和位置更新最小距离
    self.locationM.distanceFilter = 1;
    
    self.locationM.desiredAccuracy = kCLLocationAccuracyBestForNavigation;
}

#pragma mark - MKMapViewDelegate
/**
 *  当地图获取到用户位置时调用
 *
 *  @param mapView      地图
 *  @param userLocation 大头针数据模型
 */
-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    CLLocation *location = userLocation.location;
    
    if (location.horizontalAccuracy < 0) return;
    CLLocationCoordinate2D coordinate = location.coordinate;//位置坐标
    CGFloat longitude = coordinate.longitude;//经度
    CGFloat latitude = coordinate.latitude;//纬度
    CGFloat altitude = location.altitude;//海拔
    CGFloat course = location.course;//方向
    CGFloat speed = location.speed;//速度
    //    NSLog(@"经度:%f,纬度:%f",longitude,latitude);
    //    NSLog(@"海拔:%f,方向:%f,速度:%f",altitude,course,speed);
    //如果不需要实时定位，使用完即使关闭定位服务
    //    [self.locationM stopUpdatingLocation];
    
    [self.horizontalAccuracyLabel setText:[NSString stringWithFormat:@"%f",location.horizontalAccuracy]];
    [self.verticalAccuracyLabel setText:[NSString stringWithFormat:@"%f",location.verticalAccuracy]];
    [self.longitudeLabel setText:[NSString stringWithFormat:@"%f",longitude]];
    [self.latitudeLabel setText:[NSString stringWithFormat:@"%f",latitude]];
    [self.altitudeLabel setText:[NSString stringWithFormat:@"%f",altitude]];
    [self.courseLabel setText:[NSString stringWithFormat:@"%f",course]];
    [self.speedLabel setText:[NSString stringWithFormat:@"%f",speed]];
    
    //将经，纬度加入数组
    if (latitude == 0 && longitude == 0) return;
    CLLocation *nowLocation = [[CLLocation alloc] initWithLatitude:latitude longitude:longitude];
    [self.rePlayArray addObject:nowLocation];
    
    
    [self getAddressByLatitude:latitude longitude:longitude];
    
    
    [self drawMapLine];
}

/**
 *  地图区域已经改变时
 *
 *  @param mapView  地图
 *  @param animated 动画
 */
-(void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
//    NSLog(@"%f---%f", mapView.region.span.latitudeDelta, mapView.region.span.longitudeDelta);
}

/**
 *  地图区域将要改变时
 *
 *  @param mapView  地图
 *  @param animated 动画
 */
-(void)mapView:(MKMapView *)mapView regionWillChangeAnimated:(BOOL)animated
{
    
}

#pragma mark - CLLocationManagerDelegate
// 当用户授权状态发生变化时调用
- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    switch (status) {
        case kCLAuthorizationStatusNotDetermined://用户还未决定
        {
            NSLog(@"用户还未决定");
            break;
        }
        case kCLAuthorizationStatusRestricted://访问受限
        {
            NSLog(@"访问受限");
            break;
        }
        case kCLAuthorizationStatusDenied://定位关闭时或用户APP授权为永不授权时调用
        {
            NSLog(@"定位关闭或者用户未授权");
            break;
        }
        case kCLAuthorizationStatusAuthorizedAlways://获取前后台定位授权
        {
            NSLog(@"获取前后台定位授权");
            [self.locationM startUpdatingLocation];
            break;
        }
        case kCLAuthorizationStatusAuthorizedWhenInUse://获得前台定位授权
        {
            NSLog(@"获得前台定位授权");
            [self.locationM startUpdatingLocation];
            break;
        }
        default:break;
    }
}

-(void)getAddressByLatitude:(CLLocationDegrees)latitude longitude:(CLLocationDegrees)longitude{
    //反地理编码
    CLLocation *location=[[CLLocation alloc]initWithLatitude:latitude longitude:longitude];
    [_geocoder reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error) {
        CLPlacemark *placemark=[placemarks firstObject];
        NSLog(@"详细信息:%@",placemark.addressDictionary);
    }];
}

//在对应的代理方法中获取位置信息
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation*> *)locations
{
//    CLLocation *location = [locations firstObject];//取出第一个位置
    /*
     使用位置前, 务必判断当前获取的位置是否有效
     如果水平精确度小于零, 代表虽然可以获取位置对象, 但是数据错误, 不可用
     */
//    if (location.horizontalAccuracy < 0) return;
//    CLLocationCoordinate2D coordinate = location.coordinate;//位置坐标
//    CGFloat longitude = coordinate.longitude;//经度
//    CGFloat latitude = coordinate.latitude;//纬度
//    CGFloat altitude = location.altitude;//海拔
//    CGFloat course = location.course;//方向
//    CGFloat speed = location.speed;//速度
////    NSLog(@"经度:%f,纬度:%f",longitude,latitude);
////    NSLog(@"海拔:%f,方向:%f,速度:%f",altitude,course,speed);
//    //如果不需要实时定位，使用完即使关闭定位服务
////    [self.locationM stopUpdatingLocation];
//    
//    [self.horizontalAccuracyLabel setText:[NSString stringWithFormat:@"%f",location.horizontalAccuracy]];
//    [self.verticalAccuracyLabel setText:[NSString stringWithFormat:@"%f",location.verticalAccuracy]];
//    [self.longitudeLabel setText:[NSString stringWithFormat:@"%f",longitude]];
//    [self.latitudeLabel setText:[NSString stringWithFormat:@"%f",latitude]];
//    [self.altitudeLabel setText:[NSString stringWithFormat:@"%f",altitude]];
//    [self.courseLabel setText:[NSString stringWithFormat:@"%f",course]];
//    [self.speedLabel setText:[NSString stringWithFormat:@"%f",speed]];
//    
//    //将经，纬度加入数组
//    CLLocation *nowLocation = [[CLLocation alloc] initWithLatitude:latitude longitude:longitude];
//    
//    [self.rePlayArray addObject:nowLocation];
//    
//    [self drawMapLine];
}

//实现画线的代理方法
- (MKPolylineRenderer *)mapView:(MKMapView *)mapView viewForOverlay:(id<MKOverlay>)overlay{
    
    if ([overlay isKindOfClass:[MKPolyline class]]) {
        
        MKPolylineRenderer *line = [[MKPolylineRenderer alloc] initWithOverlay:overlay];
        line.strokeColor = [UIColor orangeColor];
        line.lineWidth = 3.5f;
        return line;
        
    }else{
        
        return nil;
        
    }
}

-(void)drawMapLine{

    NSInteger pointCount = self.rePlayArray.count;
    
    CLLocationCoordinate2D *coordinateArray = (CLLocationCoordinate2D *)malloc(pointCount * sizeof(CLLocationCoordinate2D));
    
    for (int i = 0; i < pointCount; i++)
    {
        CLLocation *location = [self.rePlayArray objectAtIndex:i];
        coordinateArray[i] = [location coordinate];
    }
   
    MKPolyline *lines = [MKPolyline polylineWithCoordinates:coordinateArray count:pointCount];
    [self.map addOverlay:lines];
//    MKCoordinateSpan span ={0.03,0.04};
//    MKCoordinateRegion regon = MKCoordinateRegionMake(coordinateArray[0], span);
//    [self.map setRegion:regon animated:YES];
    
}

//-(void)viewWillAppear:(BOOL)animated{
//    
//    [self.locationM startUpdatingLocation];
//}
//
//-(void)viewWillDisappear:(BOOL)animated{
//
//    [self.locationM stopUpdatingLocation];
//}

#pragma mark - didReceiveMemoryWarning
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
