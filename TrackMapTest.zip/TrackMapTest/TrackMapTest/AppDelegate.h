//
//  AppDelegate.h
//  TrackMapTest
//
//  Created by 通拓科技 on 16/4/26.
//  Copyright © 2016年 tomtop. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

