//
//  main.m
//  TrackMapTest
//
//  Created by 通拓科技 on 16/4/26.
//  Copyright © 2016年 tomtop. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
